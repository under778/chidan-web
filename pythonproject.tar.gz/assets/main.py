# -*- coding: utf-8 -*-
"""
横向2D吃丹修仙游戏 —— Web (Pygbag) 适配版
主要修改：
1. 引入 asyncio 适配网页的异步主循环
2. 存档改为使用浏览器的 localStorage
3. 字体强制加载本地 game_font.ttf
4. 资源文件名统一改为英文
"""

import pygame
import sys
import random
import time
import pickle
import os
import asyncio
import base64

# ==================== 网页环境判断 ====================
SHI_WEB = sys.platform == "emscripten"
if SHI_WEB:
    import platform

    window = platform.window  # Pygbag 提供的浏览器接口

# ==================== 初始化pygame ====================
pygame.init()
try:
    pygame.mixer.init()
except Exception:
    pass

# ==================== 常量定义 ====================
PING_MU_KD = 1200
PING_MU_GD = 600
DI_MIAN_Y = 400
DAN_YAO_JG = 200
DAN_YAO_KS = 200
YD_SU_DU = 5
ZHEN_LV = 60
GUA_JI_CHI_ZD = 200
LUN_HUI_AN_MS = 10

# 网页端不需要 pkl 文件，本地端保留
CUN_DANG_WJ = "cundang.pkl"

YS_BAI = (255, 255, 255)
YS_HEI = (0, 0, 0)
YS_HONG = (255, 0, 0)
YS_LV = (0, 255, 0)
YS_LAN = (0, 0, 255)
YS_HUANG = (255, 255, 0)
YS_CHENG = (255, 165, 0)
YS_ZI = (128, 0, 128)
YS_HUI = (128, 128, 128)
YS_QIAN_LAN = (173, 216, 230)
YS_SHEN_LV = (0, 128, 0)
YS_TU = (139, 69, 19)
YS_JIN = (255, 215, 0)

DAN_WEI_LB = ['', '万', '亿', '兆', '京', '垓', '秭', '穰', '沟', '涧',
              '正', '载', '极', '恒河沙', '阿僧祇', '那由他', '不可思议',
              '无量', '大数', '无敌']


def shu_zi_zhuan_huan(shu_zi):
    if shu_zi < 10000:
        return str(int(shu_zi))
    for i in range(len(DAN_WEI_LB) - 1, 0, -1):
        ji_shu = 10 ** (4 * i)
        if shu_zi >= ji_shu:
            zhi = shu_zi / ji_shu
            return f"{zhi:.4f}{DAN_WEI_LB[i]}"
    return str(shu_zi)


def jie_xi_dan_wei(wen_ben):
    wen_ben = wen_ben.strip()
    for i in range(len(DAN_WEI_LB) - 1, -1, -1):
        if DAN_WEI_LB[i] in wen_ben:
            shu_zi_str = wen_ben.replace(DAN_WEI_LB[i], '')
            try:
                if shu_zi_str == '' or shu_zi_str == '一':
                    shu_zi = 1.0
                else:
                    shu_zi = float(shu_zi_str)
                return int(shu_zi * (10 ** (4 * i)))
            except:
                pass
    try:
        return int(float(wen_ben))
    except:
        return 0


LUN_HUI_SL_LB = [
    "500涧", "46.5正", "4.9载", "5840载", "21极", "778极",
    "2.96恒河沙", "177恒河沙", "一阿僧祇", "70阿僧祇",
    "4650阿僧祇", "31那由他", "2200那由他", "16不可思议",
    "1180不可思议", "8无量", "700无量", "7大数",
    "120大数", "9999大数"
]
LUN_HUI_SL_ZS = [jie_xi_dan_wei(s) for s in LUN_HUI_SL_LB]


def ji_suan_dan_yao_jc(di_tu_bian_hao, jie_shu):
    jia_cheng = 10
    jia_cheng *= 5 ** (jie_shu - 1)
    if di_tu_bian_hao > 1:
        jia_cheng *= 5 ** (9 * (di_tu_bian_hao - 1))
        jia_cheng *= 20 ** (di_tu_bian_hao - 1)
    return jia_cheng


# ==================== 游戏主类 ====================
class YouXi:
    def __init__(self):
        # 注意：网页上可以强制设置窗口大小，Pygbag会自动缩放适配
        self.ping_mu = pygame.display.set_mode((PING_MU_KD, PING_MU_GD))
        pygame.display.set_caption("吃丹修仙-under")
        self.shi_zhong = pygame.time.Clock()

        # 字体：网页端必须用 ttf 文件
        try:
            self.zi_ti_da = pygame.font.Font("game_font.ttf", 30)
            self.zi_ti_zhong = pygame.font.Font("game_font.ttf", 20)
            self.zi_ti_xiao = pygame.font.Font("game_font.ttf", 14)
            self.zi_ti_jiao_cheng = pygame.font.Font("game_font.ttf", 16)
        except:
            self.zi_ti_da = pygame.font.Font(None, 30)
            self.zi_ti_zhong = pygame.font.Font(None, 20)
            self.zi_ti_xiao = pygame.font.Font(None, 14)
            self.zi_ti_jiao_cheng = pygame.font.Font(None, 16)

        # 图片：改成英文名 player.png，加上 convert_alpha 防报错
        try:
            self.wan_jia_tp = pygame.image.load("player.png").convert_alpha()
            self.wan_jia_tp = pygame.transform.scale(self.wan_jia_tp, (40, 50))
        except:
            self.wan_jia_tp = pygame.Surface((40, 50))
            self.wan_jia_tp.fill(YS_LAN)


        # 背景音乐
        try:
            pygame.mixer.music.load("bgm.ogg")
            pygame.mixer.music.set_volume(0.3)
            pygame.mixer.music.play(-1)
            print("背景音乐加载成功！")
        except Exception as e:
            print(f"BGM加载失败，错误原因: {e}")

        # 音效
        try:
            self.yin_xiao_niu = pygame.mixer.Sound("niubi.ogg")
        except:
            self.yin_xiao_niu = None
        try:
            self.yin_xiao_sha = pygame.mixer.Sound("shabi.ogg")
        except:
            self.yin_xiao_sha = None
        try:
            self.yin_xiao_pian = pygame.mixer.Sound("pian.ogg")
        except Exception:
            self.yin_xiao_pian = None

        # 玩家属性
        self.zhan_li = 3000
        self.lun_hui_cs = 0
        self.diao_luo_bl = 1
        self.lun_hui_jc = 1.0
        self.wan_jia_x = DAN_YAO_KS
        self.wan_jia_y = DI_MIAN_Y - 50

        self.dang_qian_dt = 1
        self.dang_qian_cj = "map"
        self.you_xi_zt = "youxi"
        self.she_xiang_x = 0
        self.di_tu_dan_yao = [[] for _ in range(10)]
        self.bei_lv_dan_lb = []
        self.wu_ji_dan_lb = []
        self.bei_lv_dan_jss = 0
        self.gua_ji_jss = 0
        self.kong_ge_an_x = False
        self.kong_ge_an_sj = 0
        self.lun_hui_yc = False
        self.zi_mu_wb = ""
        self.zi_mu_djs = 0
        self.shu_ru_hc = ""
        self.shu_ru_djs = 0
        self.shang_ci_qy = ""

        self.jia_zai_cun_dang()
        self.dang_qian_dy_dian = self.sheng_cheng_dy_dian(self.dang_qian_dt)

    # ==================== 存档机制（重点修复） ====================
    def baocun(self):
        cundang_data = {
            'zhan_li': self.zhan_li, 'lun_hui_cs': self.lun_hui_cs, 'diao_luo_bl': self.diao_luo_bl,
            'lun_hui_jc': self.lun_hui_jc, 'wan_jia_x': self.wan_jia_x, 'dang_qian_dt': self.dang_qian_dt,
            'dang_qian_cj': self.dang_qian_cj, 'di_tu_dan_yao': self.di_tu_dan_yao,
            'bei_lv_dan_lb': self.bei_lv_dan_lb, 'wu_ji_dan_lb': self.wu_ji_dan_lb,
            'bei_lv_dan_jss': self.bei_lv_dan_jss, 'gua_ji_jss': self.gua_ji_jss
        }

        if SHI_WEB:
            # 网页端：转成 base64 字符串存入浏览器的 localStorage
            try:
                data_str = base64.b64encode(pickle.dumps(cundang_data)).decode('utf-8')
                window.localStorage.setItem("chidan_cundang", data_str)
                print("网页存档成功")
            except Exception as e:
                print(f"网页存档失败: {e}")
        else:
            # 电脑端：写入文件
            try:
                with open(CUN_DANG_WJ, 'wb') as f:
                    pickle.dump(cundang_data, f)
            except Exception as e:
                print(f"本地存档失败: {e}")

    def jia_zai_cun_dang(self):
        data = None

        if SHI_WEB:
            # 网页端：从 localStorage 读取
            try:
                data_str = window.localStorage.getItem("chidan_cundang")
                if data_str:
                    data = pickle.loads(base64.b64decode(data_str))
            except Exception as e:
                print(f"网页读档失败: {e}")
        else:
            # 电脑端：从文件读取
            if os.path.exists(CUN_DANG_WJ):
                try:
                    with open(CUN_DANG_WJ, 'rb') as f:
                        data = pickle.load(f)
                except Exception as e:
                    print(f"本地读档失败: {e}")

        if not data:
            return

        # 恢复数据
        self.zhan_li = data.get('zhan_li', 3000)
        self.lun_hui_cs = data.get('lun_hui_cs', 0)
        self.diao_luo_bl = data.get('diao_luo_bl', 1)
        self.lun_hui_jc = data.get('lun_hui_jc', 1.0)
        self.wan_jia_x = data.get('wan_jia_x', DAN_YAO_KS)
        self.dang_qian_dt = data.get('dang_qian_dt', 1)
        self.dang_qian_cj = data.get('dang_qian_cj', 'map')
        self.di_tu_dan_yao = data.get('di_tu_dan_yao', [[] for _ in range(10)])
        self.bei_lv_dan_lb = data.get('bei_lv_dan_lb', [])
        self.wu_ji_dan_lb = data.get('wu_ji_dan_lb', [])
        self.bei_lv_dan_jss = data.get('bei_lv_dan_jss', 0)
        self.gua_ji_jss = data.get('gua_ji_jss', 0)

    # ==================== 其他绘图与逻辑函数 ====================
    def sheng_cheng_dy_dian(self, di_tu_bian_hao):
        dy_dian = []
        for jie_shu in range(1, 11):
            x = DAN_YAO_KS + (jie_shu - 1) * DAN_YAO_JG
            jia_cheng = ji_suan_dan_yao_jc(di_tu_bian_hao, jie_shu)
            ming_cheng = f"地图{di_tu_bian_hao}的{jie_shu}阶丹"
            dy_dian.append({"x": x, "jie_shu": jie_shu, "jia_cheng": jia_cheng, "ming_cheng": ming_cheng})
        return dy_dian

    def xian_shi_zi_mu(self, wen_ben):
        self.zi_mu_wb = wen_ben
        self.zi_mu_djs = 3.0

    def jian_ce_an_niu(self, shu_biao_x, shu_biao_y):
        an_niu_wz = [
            ("ditu", 10, 100, 80, 35), ("fuben", 10, 145, 80, 35),
            ("guaji", 10, 190, 80, 35), ("huicheng", 10, 235, 80, 35),
            ("jiaocheng", 10, 280, 80, 35), ("cundang", 10, 325, 80, 35)
        ]
        for ming, ax, ay, ak, ag in an_niu_wz:
            if ax <= shu_biao_x <= ax + ak and ay <= shu_biao_y <= ay + ag:
                return ming
        return None

    def hui_hua_an_niu(self):
        an_niu_lb = [
            ("地图", 10, 100, 80, 35, YS_LAN), ("副本", 10, 145, 80, 35, YS_ZI),
            ("挂机", 10, 190, 80, 35, YS_LV), ("回城", 10, 235, 80, 35, YS_CHENG),
            ("教程", 10, 280, 80, 35, YS_HUI), ("存档", 10, 325, 80, 35, YS_JIN)
        ]
        for ming, ax, ay, ak, ag, ys in an_niu_lb:
            pygame.draw.rect(self.ping_mu, ys, (ax, ay, ak, ag))
            pygame.draw.rect(self.ping_mu, YS_BAI, (ax, ay, ak, ag), 2)
            wb = self.zi_ti_xiao.render(ming, True, YS_BAI)
            self.ping_mu.blit(wb, (ax + 15, ay + 8))

    def hui_hua_zhuang_tai_lan(self):
        wb_zl = self.zi_ti_zhong.render(f"战力: {shu_zi_zhuan_huan(self.zhan_li)}", True, YS_JIN)
        self.ping_mu.blit(wb_zl, (100, 10))
        wb_lh = self.zi_ti_zhong.render(f"轮回数: {self.lun_hui_cs}", True, YS_BAI)
        self.ping_mu.blit(wb_lh, (100, 40))
        wb_bl = self.zi_ti_zhong.render(f"掉落倍率: {self.diao_luo_bl}", True, YS_BAI)
        self.ping_mu.blit(wb_bl, (100, 70))

    def hui_hua_zi_mu(self):
        if self.zi_mu_djs > 0 and self.zi_mu_wb:
            wb = self.zi_ti_da.render(self.zi_mu_wb, True, YS_HUANG)
            wb_kuan = wb.get_width()
            self.ping_mu.blit(wb, (PING_MU_KD // 2 - wb_kuan // 2, 120))

    def hui_hua_di_mian(self):
        pygame.draw.line(self.ping_mu, YS_TU, (0, DI_MIAN_Y), (PING_MU_KD, DI_MIAN_Y), 3)

    def hui_hua_dan_yao_dian(self):
        if self.dang_qian_cj != "map": return
        for dy in self.dang_qian_dy_dian:
            sx = dy["x"] - self.she_xiang_x
            if -100 <= sx <= PING_MU_KD + 100:
                pygame.draw.circle(self.ping_mu, YS_HONG, (sx, DI_MIAN_Y - 5), 8)
                wb = self.zi_ti_xiao.render(dy["ming_cheng"], True, YS_BAI)
                self.ping_mu.blit(wb, (sx - wb.get_width() // 2, DI_MIAN_Y - 40))

    def hui_hua_yi_sheng_dan(self):
        if self.dang_qian_cj == "map":
            dy_lb = self.di_tu_dan_yao[self.dang_qian_dt - 1]
            for i, dy in enumerate(dy_lb):
                sx = dy["x"] + (i % 5) * 8 - 16 - self.she_xiang_x
                sy = DI_MIAN_Y - 15 - (i // 5) * 10
                if -50 <= sx <= PING_MU_KD + 50:
                    ys = YS_ZI if "无极" in dy["ming_cheng"] else YS_LV
                    pygame.draw.circle(self.ping_mu, ys, (sx, sy), 6)
        elif self.dang_qian_cj == "fuben1":
            for i, dy in enumerate(self.bei_lv_dan_lb):
                sx = dy["x"] + (i % 5) * 8 - 16 - self.she_xiang_x
                sy = DI_MIAN_Y - 15 - (i // 5) * 10
                if -50 <= sx <= PING_MU_KD + 50:
                    pygame.draw.circle(self.ping_mu, YS_HUANG, (sx, sy), 7)
        elif self.dang_qian_cj == "fuben2":
            for i, dy in enumerate(self.wu_ji_dan_lb):
                sx = dy["x"] + (i % 5) * 8 - 16 - self.she_xiang_x
                sy = DI_MIAN_Y - 15 - (i // 5) * 10
                if -50 <= sx <= PING_MU_KD + 50:
                    pygame.draw.circle(self.ping_mu, YS_ZI, (sx, sy), 6)

    def hui_hua_wan_jia(self):
        sx = self.wan_jia_x - self.she_xiang_x
        self.ping_mu.blit(self.wan_jia_tp, (sx, self.wan_jia_y))

    def hui_hua_gua_ji_chi(self):
        if self.dang_qian_cj == "map" and self.dang_qian_dt == 1:
            for x in range(-400, GUA_JI_CHI_ZD, 50):
                sx = x - self.she_xiang_x
                if -50 <= sx <= PING_MU_KD + 50:
                    pygame.draw.rect(self.ping_mu, YS_QIAN_LAN, (sx, DI_MIAN_Y - 20, 40, 20))
            sx = 0 - self.she_xiang_x
            if -100 <= sx <= PING_MU_KD + 100:
                wb = self.zi_ti_xiao.render("挂机池", True, YS_QIAN_LAN)
                self.ping_mu.blit(wb, (sx - wb.get_width() // 2, DI_MIAN_Y - 50))

    def hui_hua_di_tu_xz(self):
        zhe_zhao = pygame.Surface((PING_MU_KD, PING_MU_GD))
        zhe_zhao.set_alpha(200)
        zhe_zhao.fill(YS_HEI)
        self.ping_mu.blit(zhe_zhao, (0, 0))
        wb = self.zi_ti_da.render("选择地图", True, YS_BAI)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 60, 50))
        for i in range(10):
            hang = i // 5
            lie = i % 5
            ax = 200 + lie * 160
            ay = 150 + hang * 150
            pygame.draw.rect(self.ping_mu, YS_LAN, (ax, ay, 140, 80))
            pygame.draw.rect(self.ping_mu, YS_BAI, (ax, ay, 140, 80), 2)
            wb = self.zi_ti_zhong.render(f"地图{i + 1}", True, YS_BAI)
            self.ping_mu.blit(wb, (ax + 35, ay + 25))
        pygame.draw.rect(self.ping_mu, YS_HUI, (PING_MU_KD // 2 - 50, 500, 100, 40))
        pygame.draw.rect(self.ping_mu, YS_BAI, (PING_MU_KD // 2 - 50, 500, 100, 40), 2)
        wb = self.zi_ti_zhong.render("返回", True, YS_BAI)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 20, 510))

    def hui_hua_fu_ben_xz(self):
        zhe_zhao = pygame.Surface((PING_MU_KD, PING_MU_GD))
        zhe_zhao.set_alpha(200)
        zhe_zhao.fill(YS_HEI)
        self.ping_mu.blit(zhe_zhao, (0, 0))
        wb = self.zi_ti_da.render("选择副本", True, YS_BAI)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 60, 50))
        pygame.draw.rect(self.ping_mu, YS_ZI, (300, 150, 250, 100))
        pygame.draw.rect(self.ping_mu, YS_BAI, (300, 150, 250, 100), 2)
        wb = self.zi_ti_zhong.render("副本1（倍率丹）", True, YS_BAI)
        self.ping_mu.blit(wb, (335, 185))
        pygame.draw.rect(self.ping_mu, YS_ZI, (650, 150, 250, 100))
        pygame.draw.rect(self.ping_mu, YS_BAI, (650, 150, 250, 100), 2)
        wb = self.zi_ti_zhong.render("副本2（无极魔丹）", True, YS_BAI)
        self.ping_mu.blit(wb, (685, 185))
        pygame.draw.rect(self.ping_mu, YS_HUI, (PING_MU_KD // 2 - 50, 500, 100, 40))
        pygame.draw.rect(self.ping_mu, YS_BAI, (PING_MU_KD // 2 - 50, 500, 100, 40), 2)
        wb = self.zi_ti_zhong.render("返回", True, YS_BAI)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 20, 510))

    def hui_hua_jiao_cheng(self):
        zhe_zhao = pygame.Surface((PING_MU_KD, PING_MU_GD))
        zhe_zhao.set_alpha(220)
        zhe_zhao.fill(YS_HEI)
        self.ping_mu.blit(zhe_zhao, (0, 0))
        wb = self.zi_ti_da.render("游戏教程", True, YS_HUANG)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 60, 20))
        jiao_cheng_wb = [
            "【基本规则】", "1. 10个主地图，每个地图有10种常规丹药生成点",
            "2. 空格键生成丹药（松开时），数量=掉落倍率", "3. Z键吃掉所有常规丹药加战力（松开时）",
            "4. 地图1一阶丹+10战力，每阶×5，跨地图×20", "5. 生成丹药需战力≥丹药加成×300",
            "6. 挂机池在地图1一阶丹左侧，每秒+0.03%战力", "", "【副本】",
            "7. 副本1：每3秒生成倍率丹，X键吃，掉落倍率+1", "8. 副本2：空格生成无极魔丹，加战力0.01%/颗",
            "", "【轮回】", "9. 长按空格10秒触发轮回询问", "10. 轮回后战力变1000，加成×1.5，最多20次",
            "", "【单位】", "万=10^4, 亿=10^8, 兆=10^12...无敌=10^76","",
            "【存档】",
            "游戏退出时自动保存，也可点击左侧“存档”按钮手动保存"
        ]
        for i, hang in enumerate(jiao_cheng_wb):
            y = 70 + i * 25
            wb = self.zi_ti_jiao_cheng.render(hang, True, YS_BAI)
            self.ping_mu.blit(wb, (50, y))
        pygame.draw.rect(self.ping_mu, YS_HUI, (PING_MU_KD // 2 - 50, 540, 100, 40))
        pygame.draw.rect(self.ping_mu, YS_BAI, (PING_MU_KD // 2 - 50, 540, 100, 40), 2)
        wb = self.zi_ti_zhong.render("返回", True, YS_BAI)
        self.ping_mu.blit(wb, (PING_MU_KD // 2 - 20, 548))

    def hui_hua_lun_hui_que_ren(self):
        zhe_zhao = pygame.Surface((PING_MU_KD, PING_MU_GD))
        zhe_zhao.set_alpha(180)
        zhe_zhao.fill(YS_HEI)
        self.ping_mu.blit(zhe_zhao, (0, 0))
        pygame.draw.rect(self.ping_mu, YS_HUI, (250, 180, 700, 240))
        pygame.draw.rect(self.ping_mu, YS_JIN, (250, 180, 700, 240), 3)
        suo_xu = LUN_HUI_SL_ZS[self.lun_hui_cs] if self.lun_hui_cs < 20 else 0
        wb1 = self.zi_ti_da.render("是否轮回？", True, YS_HONG)
        self.ping_mu.blit(wb1, (PING_MU_KD // 2 - 80, 200))
        wb2 = self.zi_ti_zhong.render(f"当前轮回数: {self.lun_hui_cs}", True, YS_BAI)
        self.ping_mu.blit(wb2, (300, 250))
        wb3 = self.zi_ti_zhong.render(f"所需战力: {shu_zi_zhuan_huan(suo_xu)}", True, YS_BAI)
        self.ping_mu.blit(wb3, (300, 280))
        wb4 = self.zi_ti_zhong.render(f"当前战力: {shu_zi_zhuan_huan(self.zhan_li)}", True, YS_BAI)
        self.ping_mu.blit(wb4, (300, 310))
        if self.zhan_li >= suo_xu:
            wb5 = self.zi_ti_zhong.render("✔ 战力充足，可以轮回！", True, YS_LV)
        else:
            wb5 = self.zi_ti_zhong.render("✘ 战力不足，无法轮回！", True, YS_HONG)
        self.ping_mu.blit(wb5, (300, 340))
        pygame.draw.rect(self.ping_mu, YS_LV, (350, 380, 120, 40))
        pygame.draw.rect(self.ping_mu, YS_BAI, (350, 380, 120, 40), 2)
        wb = self.zi_ti_zhong.render("确认(Y)", True, YS_BAI)
        self.ping_mu.blit(wb, (370, 390))
        pygame.draw.rect(self.ping_mu, YS_HONG, (730, 380, 120, 40))
        pygame.draw.rect(self.ping_mu, YS_BAI, (730, 380, 120, 40), 2)
        wb = self.zi_ti_zhong.render("取消(N)", True, YS_BAI)
        self.ping_mu.blit(wb, (750, 390))

    def jin_ru_di_tu(self, di_tu_bian_hao):
        self.dang_qian_dt = di_tu_bian_hao
        self.dang_qian_cj = "map"
        self.wan_jia_x = DAN_YAO_KS
        self.dang_qian_dy_dian = self.sheng_cheng_dy_dian(di_tu_bian_hao)
        self.shang_ci_qy = ""
        self.xian_shi_zi_mu(f"进入地图{di_tu_bian_hao}")

    def jin_ru_fu_ben(self, fu_ben_bian_hao):
        if fu_ben_bian_hao == 1:
            self.dang_qian_cj = "fuben1"
            self.wan_jia_x = 200
            self.xian_shi_zi_mu("进入副本1（倍率丹）")
        elif fu_ben_bian_hao == 2:
            self.dang_qian_cj = "fuben2"
            self.wan_jia_x = 200
            self.xian_shi_zi_mu("进入副本2（无极魔丹）")
        self.shang_ci_qy = ""

    def gua_ji(self):
        self.dang_qian_dt = 1
        self.dang_qian_cj = "map"
        self.wan_jia_x = 100
        self.dang_qian_dy_dian = self.sheng_cheng_dy_dian(1)
        self.shang_ci_qy = ""
        self.xian_shi_zi_mu("进入挂机池")

    def hui_cheng(self):
        self.dang_qian_dt = 1
        self.dang_qian_cj = "map"
        self.wan_jia_x = DAN_YAO_KS
        self.dang_qian_dy_dian = self.sheng_cheng_dy_dian(1)
        self.shang_ci_qy = ""
        self.xian_shi_zi_mu("回城")

    def sheng_cheng_dan_yao(self):
        if self.dang_qian_cj != "map": return
        for dy in self.dang_qian_dy_dian:
            if abs(self.wan_jia_x - dy["x"]) < 40:
                suo_xu = dy["jia_cheng"] * 300
                if self.zhan_li >= suo_xu:
                    for i in range(self.diao_luo_bl):
                        self.di_tu_dan_yao[self.dang_qian_dt - 1].append({
                            "x": dy["x"] + random.randint(-20, 20), "y": DI_MIAN_Y - 15,
                            "ming_cheng": dy["ming_cheng"], "jia_cheng": dy["jia_cheng"], "lei_xing": "chang_gui"
                        })
                    self.xian_shi_zi_mu(f"生成{self.diao_luo_bl}个{dy['ming_cheng']}")
                else:
                    self.xian_shi_zi_mu(f"战力不足！需要{shu_zi_zhuan_huan(suo_xu)}战力")
                return
        self.xian_shi_zi_mu("不在丹药生成点附近")

    def sheng_cheng_wu_ji_dan(self):
        if self.dang_qian_cj != "fuben2": return
        gai_lv = random.random()
        if gai_lv < 0.60:
            shu_liang = 1
        elif gai_lv < 0.90:
            shu_liang = 3
        elif gai_lv < 0.9999:
            shu_liang = 5
        else:
            shu_liang = 20
        for i in range(shu_liang):
            self.wu_ji_dan_lb.append({
                "x": self.wan_jia_x + random.randint(-30, 30), "y": DI_MIAN_Y - 15,
                "ming_cheng": "无极魔丹", "jia_cheng": 0, "lei_xing": "wu_ji"
            })
        self.xian_shi_zi_mu(f"生成{shu_liang}颗无极魔丹！")

    def chi_suo_you_dan(self):
        chi_le = 0
        zong_jia = 0
        if self.dang_qian_cj == "map":
            dy_lb = self.di_tu_dan_yao[self.dang_qian_dt - 1]
            for dy in dy_lb:
                jia_cheng = int(dy["jia_cheng"] * self.lun_hui_jc)
                self.zhan_li += jia_cheng
                zong_jia += jia_cheng
                chi_le += 1
            dy_lb.clear()
        elif self.dang_qian_cj == "fuben2":
            for dy in self.wu_ji_dan_lb:
                jia_cheng = int(self.zhan_li * 0.0001 * self.lun_hui_jc)
                if jia_cheng < 1: jia_cheng = 1
                self.zhan_li += jia_cheng
                zong_jia += jia_cheng
                chi_le += 1
            self.wu_ji_dan_lb.clear()
        if chi_le > 0:
            self.xian_shi_zi_mu(f"吃掉{chi_le}颗丹药，战力+{shu_zi_zhuan_huan(zong_jia)}")
        else:
            self.xian_shi_zi_mu("没有可吃的丹药")

    def chi_bei_lv_dan(self):
        if self.dang_qian_cj != "fuben1": return
        if len(self.bei_lv_dan_lb) > 0:
            self.bei_lv_dan_lb.pop(0)
            self.diao_luo_bl += 1
            self.xian_shi_zi_mu(f"吃倍率丹！掉落倍率+1，当前{self.diao_luo_bl}")
        else:
            self.xian_shi_zi_mu("没有倍率丹可吃")

    def lun_hui(self):
        suo_xu = LUN_HUI_SL_ZS[self.lun_hui_cs] if self.lun_hui_cs < 20 else 0
        if self.zhan_li >= suo_xu and self.lun_hui_cs < 20:
            self.zhan_li = 1000
            self.lun_hui_cs += 1
            self.lun_hui_jc *= 1.5
            self.xian_shi_zi_mu(f"轮回成功！第{self.lun_hui_cs}次轮回，加成×1.5")
            self.you_xi_zt = "youxi"
        else:
            self.xian_shi_zi_mu("战力不足或已达最大轮回次数！")
            self.you_xi_zt = "youxi"

    def jian_ce_qu_yu(self):
        if self.dang_qian_cj == "map":
            if self.dang_qian_dt == 1 and self.wan_jia_x < GUA_JI_CHI_ZD:
                qy = "挂机池"
            else:
                qy = ""
                for dy in self.dang_qian_dy_dian:
                    if abs(self.wan_jia_x - dy["x"]) < 40: qy = dy["ming_cheng"]; break
            if qy and qy != self.shang_ci_qy:
                self.shang_ci_qy = qy; self.xian_shi_zi_mu(qy)
            elif not qy:
                self.shang_ci_qy = ""
        elif self.dang_qian_cj == "fuben1":
            if "副本1" != self.shang_ci_qy: self.shang_ci_qy = "副本1"; self.xian_shi_zi_mu("副本1")
        elif self.dang_qian_cj == "fuben2":
            if "副本2" != self.shang_ci_qy: self.shang_ci_qy = "副本2"; self.xian_shi_zi_mu("副本2")

    def jian_ce_cai_dan(self):
        if (self.dang_qian_cj == "map" and self.dang_qian_dt == 6 and abs(self.wan_jia_x - 1200) < 40):
            if "under" in self.shu_ru_hc.lower():
                if self.yin_xiao_niu: self.yin_xiao_niu.play()
                self.xian_shi_zi_mu("彩蛋触发：！？under？！")
                self.shu_ru_hc = ""
        if (self.dang_qian_cj == "map" and self.dang_qian_dt == 7 and abs(self.wan_jia_x - 1600) < 40):
            if "liwu" in self.shu_ru_hc.lower():
                if self.yin_xiao_sha: self.yin_xiao_sha.play()
                self.xian_shi_zi_mu("彩蛋触发：傻逼！")
                self.shu_ru_hc = ""
        if (self.dang_qian_cj == "map" and self.dang_qian_dt == 9 and abs(self.wan_jia_x - 200) < 40):
            if "jibajiabi" in self.shu_ru_hc.lower():
                if self.yin_xiao_pian: self.yin_xiao_pian.play()
                self.xian_shi_zi_mu("最神秘彩蛋")
                self.shu_ru_hc = ""
    def geng_xin(self, shi_jian_dt):
        self.she_xiang_x = self.wan_jia_x - PING_MU_KD // 2
        if self.she_xiang_x < -500: self.she_xiang_x = -500
        if self.she_xiang_x > 2500: self.she_xiang_x = 2500
        if self.zi_mu_djs > 0:
            self.zi_mu_djs -= shi_jian_dt
            if self.zi_mu_djs <= 0: self.zi_mu_wb = ""
        if self.shu_ru_djs > 0:
            self.shu_ru_djs -= shi_jian_dt
            if self.shu_ru_djs <= 0: self.shu_ru_hc = ""
        if (self.dang_qian_cj == "map" and self.dang_qian_dt == 1 and self.wan_jia_x < GUA_JI_CHI_ZD):
            self.gua_ji_jss += shi_jian_dt
            if self.gua_ji_jss >= 1.0:
                self.gua_ji_jss -= 1.0
                jia_cheng = int(self.zhan_li * 0.0003 * self.lun_hui_jc)
                if jia_cheng < 1: jia_cheng = 1
                self.zhan_li += jia_cheng
        if self.dang_qian_cj == "fuben1":
            self.bei_lv_dan_jss += shi_jian_dt
            if self.bei_lv_dan_jss >= 3.0:
                self.bei_lv_dan_jss -= 3.0
                self.bei_lv_dan_lb.append(
                    {"x": 300 + random.randint(-50, 50), "y": DI_MIAN_Y - 15, "ming_cheng": "倍率丹",
                     "lei_xing": "bei_lv"})
        self.jian_ce_qu_yu()
        self.jian_ce_cai_dan()
        if self.kong_ge_an_x and not self.lun_hui_yc:
            if time.time() - self.kong_ge_an_sj >= LUN_HUI_AN_MS:
                self.lun_hui_yc = True
                self.you_xi_zt = "lunhuixr"

    def hui_hua(self):
        self.ping_mu.fill(YS_HEI)
        if self.you_xi_zt == "youxi":
            self.hui_hua_di_mian()
            self.hui_hua_dan_yao_dian()
            self.hui_hua_gua_ji_chi()
            self.hui_hua_yi_sheng_dan()
            self.hui_hua_wan_jia()
            self.hui_hua_zhuang_tai_lan()
            self.hui_hua_an_niu()
            self.hui_hua_zi_mu()
        elif self.you_xi_zt == "dituxz":
            self.hui_hua_di_tu_xz()
        elif self.you_xi_zt == "fubenxz":
            self.hui_hua_fu_ben_xz()
        elif self.you_xi_zt == "jiaocheng":
            self.hui_hua_jiao_cheng()
        elif self.you_xi_zt == "lunhuixr":
            self.hui_hua_lun_hui_que_ren()
        pygame.display.flip()

    def chu_li_shu_biao_dian_ji(self, x, y):
        if self.you_xi_zt == "youxi":
            an_niu = self.jian_ce_an_niu(x, y)
            if an_niu == "ditu":
                self.you_xi_zt = "dituxz"
            elif an_niu == "fuben":
                self.you_xi_zt = "fubenxz"
            elif an_niu == "guaji":
                self.gua_ji()
            elif an_niu == "huicheng":
                self.hui_cheng()
            elif an_niu == "jiaocheng":
                self.you_xi_zt = "jiaocheng"
            elif an_niu == "cundang":
                self.baocun(); self.xian_shi_zi_mu("游戏已保存！")
        elif self.you_xi_zt == "dituxz":
            for i in range(10):
                hang = i // 5
                lie = i % 5
                ax = 200 + lie * 160
                ay = 150 + hang * 150
                if ax <= x <= ax + 140 and ay <= y <= ay + 80:
                    self.jin_ru_di_tu(i + 1)
                    self.you_xi_zt = "youxi"
                    return
            if PING_MU_KD // 2 - 50 <= x <= PING_MU_KD // 2 + 50 and 500 <= y <= 540:
                self.you_xi_zt = "youxi"
        elif self.you_xi_zt == "fubenxz":
            if 300 <= x <= 550 and 150 <= y <= 250:
                self.jin_ru_fu_ben(1); self.you_xi_zt = "youxi"
            elif 650 <= x <= 900 and 150 <= y <= 250:
                self.jin_ru_fu_ben(2); self.you_xi_zt = "youxi"
            elif PING_MU_KD // 2 - 50 <= x <= PING_MU_KD // 2 + 50 and 500 <= y <= 540:
                self.you_xi_zt = "youxi"
        elif self.you_xi_zt == "jiaocheng":
            if PING_MU_KD // 2 - 50 <= x <= PING_MU_KD // 2 + 50 and 540 <= y <= 580: self.you_xi_zt = "youxi"
        elif self.you_xi_zt == "lunhuixr":
            if 350 <= x <= 470 and 380 <= y <= 420:
                self.lun_hui()
            elif 730 <= x <= 850 and 380 <= y <= 420:
                self.you_xi_zt = "youxi"
                self.lun_hui_yc = False
                self.kong_ge_an_x = False

    def chu_li_an_jian_an_x(self, jian):
        if jian == pygame.K_SPACE:
            if not self.kong_ge_an_x:
                self.kong_ge_an_x = True
                self.kong_ge_an_sj = time.time()
                self.lun_hui_yc = False
        if self.you_xi_zt == "youxi":
            try:
                zi_fu = pygame.key.name(jian)
                if pygame.key.get_mods() & pygame.KMOD_SHIFT:
                    zi_fu = zi_fu.upper()
                else:
                    zi_fu = zi_fu.lower()
                if zi_fu and len(zi_fu) == 1 and zi_fu.isalpha():
                    self.shu_ru_hc += zi_fu
                    self.shu_ru_djs = 3.0
                    if len(self.shu_ru_hc) > 20:
                        self.shu_ru_hc = self.shu_ru_hc[-20:]
            except:
                pass

    def chu_li_an_jian_tai_qi(self, jian):
        if self.you_xi_zt != "youxi": return
        if jian == pygame.K_SPACE:
            an_shi_duan = time.time() - self.kong_ge_an_sj
            self.kong_ge_an_x = False
            if an_shi_duan < LUN_HUI_AN_MS:
                if self.dang_qian_cj == "map":
                    self.sheng_cheng_dan_yao()
                elif self.dang_qian_cj == "fuben2":
                    self.sheng_cheng_wu_ji_dan()
        elif jian == pygame.K_z:
            self.chi_suo_you_dan()
        elif jian == pygame.K_x:
            self.chi_bei_lv_dan()
        elif jian == pygame.K_y:
            if self.you_xi_zt == "lunhuixr": self.lun_hui()
        elif jian == pygame.K_n:
            if self.you_xi_zt == "lunhuixr":
                self.you_xi_zt = "youxi"
                self.lun_hui_yc = False
                self.kong_ge_an_x = False

    # ==================== 异步主循环 (重点) ====================
    async def yun_xing(self):
        yun_xing = True
        while yun_xing:
            shi_jian_dt = self.shi_zhong.tick(ZHEN_LV) / 1000.0

            for shi_jian in pygame.event.get():
                if shi_jian.type == pygame.QUIT:
                    self.baocun()
                    yun_xing = False
                elif shi_jian.type == pygame.KEYDOWN:
                    self.chu_li_an_jian_an_x(shi_jian.key)
                elif shi_jian.type == pygame.KEYUP:
                    self.chu_li_an_jian_tai_qi(shi_jian.key)
                elif shi_jian.type == pygame.MOUSEBUTTONDOWN:
                    if shi_jian.button == 1:
                        self.chu_li_shu_biao_dian_ji(*shi_jian.pos)

            if self.you_xi_zt == "youxi":
                an_jian = pygame.key.get_pressed()
                if an_jian[pygame.K_LEFT]: self.wan_jia_x -= YD_SU_DU
                if an_jian[pygame.K_RIGHT]: self.wan_jia_x += YD_SU_DU

                if self.dang_qian_cj == "map":
                    if self.wan_jia_x < -450: self.wan_jia_x = -450
                    if self.wan_jia_x > 2450: self.wan_jia_x = 2450
                else:
                    if self.wan_jia_x < -450: self.wan_jia_x = -450
                    if self.wan_jia_x > 1450: self.wan_jia_x = 1450

            self.geng_xin(shi_jian_dt)
            self.hui_hua()

            # 核心：必须让出控制权给浏览器，否则网页会卡死！
            await asyncio.sleep(0)

        pygame.quit()


# ==================== 程序入口 ====================
if __name__ == "__main__":
    you_xi = YouXi()
    # 用 asyncio 运行主循环
    asyncio.run(you_xi.yun_xing())